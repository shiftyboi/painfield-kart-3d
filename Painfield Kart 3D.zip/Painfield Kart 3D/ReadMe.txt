HOW TO PLAY:

1. Unzip .zip (Right click and press extract all)
2. Run the .exe
3. Enjoy the pain
 
Note: There is no exit button; press Alt+F4 to exit